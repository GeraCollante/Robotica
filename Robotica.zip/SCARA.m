%ROBOT SCARA

clc; clear all;
syms tita1 d1 a1 tita2 a2 d3 tita4 d4
T = DH(tita1, d1, a1,0)*DH(tita2, 0, a2, pi)*DH(0,d3,0,0)*DH(-tita4,d4,0,0)
a1 = 0.7;
a2 = 0.5;
d1 = 0.4;
d3 = 0.3; %Pieza prismatica
d4 = 0.5; 
i=1;
flechaDH(0,0,0,0);
for tita1 = 0.0:pi/16:pi
    for tita2 = 0.0:pi/16:pi
        for d3 = 0.0:1:1
            for tita4 = 0.0:pi/16:pi  
                Aux=eval(T);
                posX(i)=Aux(1,4);        %Eje x
                posY(i)=Aux(2,4);       %Eje y
                posZ(i)=Aux(3,4);        %Eje z
                figure(1)
%                 stem3(posX(i), posY(i), posZ(i))
%                 grid on
%                 hold on
                i=i+1;
            end
        end
    end
end

plot3(posX,posY,posZ);grid